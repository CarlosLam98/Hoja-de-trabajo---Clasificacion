library(odbc)
con <- dbConnect(odbc(), Driver = "SQL Server", Server = "DESKTOP-D0GH343", Database = "COVID")

query <- dbSendQuery(con, 'SELECT * from dbo.V_Salud_12')                

#Dataset del query
COVID_Salud <- dbFetch(query)

COVID_Salud <- na.omit(COVID_Salud)

#Agregamos una columna
COVID_Salud$Fallecio <- ifelse(COVID_Salud$FECHA_DEF == "9999-99-99", FALSE, TRUE)

#Calculamos el numero de columnas que pertenecen al 80% y al restante
Porcentaje80 <- nrow(COVID_Salud) * 0.8
UltimosPorcentaje <- nrow(COVID_Salud) - Porcentaje80

#Partimos el dataSet en dos nuevos datasets
Primeros <- head(COVID_Salud, n=Porcentaje80)
Ultimos <-tail(COVID_Salud, n=UltimosPorcentaje)

#Naive Bayes
#install.packages("e1071")
library("e1071")
modelNB <- naiveBayes(Fallecio ~ EDAD+SEXO+DIABETES+EPOC+ASMA+INMUSUPR+HIPERTENSION+OTRA_COM+CARDIOVASCULAR+OBESIDAD+RENAL_CRONICA+TABAQUISMO, Primeros)
resultsNB <- predict(modelNB,Ultimos)

#Arbol de decisiones
#install.packages("rpart.plot")
#install.packages("rattle")
library("rpart")
library("rpart.plot")
library("rattle")
library("RColorBrewer")

modelArbol <- rpart(Fallecio ~ EDAD + SEXO + DIABETES + EPOC + ASMA + INMUSUPR + HIPERTENSION + OTRA_COM + CARDIOVASCULAR + OBESIDAD + RENAL_CRONICA + TABAQUISMO, 
                    data = Primeros,method = "class",  control = rpart.control(minsplit = 1))
summary(modelArbol)
rpart.plot(modelArbol, type = 4, extra = 1)

resultsArbol <- predict(modelArbol, Ultimos, type=c("class"))

#Matriz de confusion para Bayes
MCB <- table(resultsNB, Ultimos$Fallecio)

#Matriz de confusion para Arbol
MCA <- table(resultsArbol, Ultimos$Fallecio)

MCB
MCA

#Sumamos falsos positivos y falsos negativos
MCB[2,1] + MCB[1,2]
MCA[2,1] + MCA[1,2]

#install.packages("ROCR")
library("ROCR")

pred <- predict(modelArbol, Ultimos)

predObj = prediction(pred[,2], Ultimos$Fallecio)

rocObj = performance(predObj, measure = "tpr", x.measure = "fpr")
aucObj = performance(predObj, measure = "auc")

auc = aucObj@y.values[[1]]
auc
plot(rocObj, main= paste("Area bajo la curva Arbol de Desicion", auc))

#objeto de predicion de bayes
pred <- predict(modelNB, Ultimos, type = "c"("raw"))

predObj <- prediction(pred[,2], Ultimos$Fallecio)

rocObj = performance(predObj, measure = "tpr", x.measure = "fpr")
aucObj = performance(predObj, measure = "auc")

auc = aucObj@y.values[[1]]
auc
plot(rocObj, main= paste("Area bajo la curva Naive Bayes", auc))
